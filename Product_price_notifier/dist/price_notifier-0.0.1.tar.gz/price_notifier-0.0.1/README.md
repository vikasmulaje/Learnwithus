Ecommerce Product Price Notifier


Create a Tool which will notify users when required ecommerce Products will be available in users price range.


Scenario: As a user I want to buy a mobile phone right now but the current price(20000) is way above my budget price(15000) as prices keep fluctuating. I want a way to get notified when the price is in my budget.




Project will hosted in this repo

https://github.com/vikasmulaje/Learnwithus/tree/main/Product_price_notifier




